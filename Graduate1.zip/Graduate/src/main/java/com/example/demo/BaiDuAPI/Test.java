package com.example.demo.BaiDuAPI;

public class Test {
    public static void main(String[] args) {
//      String str = "{\"type\":\"smile\",\"probability\":1}}]}}";
//        System.out.println(str.split(",")[0].split(":")[1]);
        System.out.println("".toString());
        String str = null;
        System.out.println(str.toString());
    }
}
