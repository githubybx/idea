package com.example.demo.UserInfo;

public class Student {
    String name;
    String age;
    int money;
}
