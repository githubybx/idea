package com.example.demo.Emotion;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Map;

@RestController
public class EmotionController {
    @Autowired
    EmotionService emotionService;
    //更新商品的数据信息
    @RequestMapping("/post/update/goodsEmotionMsg")
    public void updateGoodsMsg() throws IOException {
        String path = "";
        int pid = 0;
      emotionService.faceDetectResult(path, pid);
    }
}
