package com.example.huarun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HuarunApplicationTests {

    @Test
    void contextLoads() {
    }

}
