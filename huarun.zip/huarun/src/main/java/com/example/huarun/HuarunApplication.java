package com.example.huarun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HuarunApplication {

    public static void main(String[] args) {
        SpringApplication.run(HuarunApplication.class, args);
    }

}
